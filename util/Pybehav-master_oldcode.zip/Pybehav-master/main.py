# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 13:26:33 2019

@author: slee
"""
import sys
sys.path.insert(0,'/home/pi/dev/Pybehav')
from time import sleep
from Threadworker import *
from Daq import *
from Wheel import Wheel   
from mcc_dio import *

# test function
# start DAQ thread
params={'channels':(0,1), 'scan_rate':5000, 'mode':'continuous', 'timeout':5,'acq_dur':1}
d = DAQ(params)
d.init_daq()
d.worker.start()
sleep(0.01)

## start wheel thread
whparam ={'channels':(0,1), 'daq':d}
wh = Wheel(whparam)
wh.worker.start()
sleep(0.01)

dio = MCC152_DIO([0,1],[6,7],False)
dio.worker.start()

#sleep(30)
#
#print(d.worker.check_datflag())
#
d.worker.pause()
d.acq_cleanup()
wh.worker.pause()
dio.dio_stop()

#d1.worker.pause()
#d1.acq_cleanup()

# test mcc152_dio



#dio.worker.start()


#dio.worker.pause()

#########################33333
#import time
#time.localtime(d.timer.start_time)

### saving class object
#import pickle
#class c:
#    def __init__(self,d):
#        self.data = d.data
#        self.t = d.t
#        self.acq_counter= d.acq_counter
#        self.total_nsample_perchannel = d.total_nsample_perchannel 
#        self.data_acqtime = d.data_acqtime
#        self.data_len = d.data_len
#        self.scan_rate = d.scan_rate
#        self.total_nsample_perchannel = d.total_nsample_perchannel
#        self.ch = d.ch
#        
#a = c(d) 
#fh = open('daq-2.obj','wb')
#pickle.dump(a,fh)
#fh.close()
#
#with open('Z:\Pybehav\daq-2.obj', 'rb') as daqfile:
#    daq = pickle.load(daqfile)
# 
    

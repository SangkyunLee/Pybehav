import scipy.io as sio
import numpy as np
import matplotlib.pyplot as plt 
from time import time
import os
import sys
os.chdir('/home/pi/dev/Pybehav')
sys.path.insert(1,'/home/pi/dev/Pybehav/ref/')

from Wheel import *


D=sio.loadmat('Wheel.mat')
sig = D['sig']
tsec =D['tsec']
tsec = tsec[0]




seltrange = (81,81.5)
inx= np.logical_and(tsec>seltrange[0] , tsec<seltrange[1])
sig1 = sig[inx,:]
tsec1 = tsec[inx]
twin =0.1
c = time()
speed_t = get_whspeed(sig1,tsec1,twin)
lap = (time()- c)
print('elapsetime:' + str(lap))
plt.plot(tsec1,speed_t)




